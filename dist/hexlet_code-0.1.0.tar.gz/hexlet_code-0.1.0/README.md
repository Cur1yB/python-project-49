### Hexlet tests and linter status:
[![Actions Status](https://github.com/Cur1yB/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Cur1yB/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/307e17da91705aad9e3e/maintainability)](https://codeclimate.com/github/Cur1yB/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/QqBBSLmXMZDPwpvExHBosCNk7)](https://asciinema.org/a/QqBBSLmXMZDPwpvExHBosCNk7?autoplay=1)

[![asciicast](https://asciinema.org/a/ajALb6F88XmwwgT9VA13tC6K8)](https://asciinema.org/a/ajALb6F88XmwwgT9VA13tC6K8?autoplay=1)

